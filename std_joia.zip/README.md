# ps_child_ZOneTheme
adattamento template grafico child
+ css default:
   row-full, extracontainer, product-name
+ modules\zonemegamenu
+ layout -> sitemap
  no store page, no brandlist

+  dependencies modules:
   - everblock
   - crazyelements
   - hooksmanager
   - pscleaner
   - orderreference